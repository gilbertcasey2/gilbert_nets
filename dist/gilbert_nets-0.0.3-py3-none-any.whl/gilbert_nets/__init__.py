from networkfx import test_all

test_all()
